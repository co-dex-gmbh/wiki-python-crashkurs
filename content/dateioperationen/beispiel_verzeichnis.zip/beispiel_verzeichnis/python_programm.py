from pathlib import Path

# Erstellen eines Pfadobjekts
pfad = Path("my_file_1.txt")

# Überprüfen, ob der Pfad existiert
if pfad.exists():
    print("Der angegebene Pfad existiert.")

# Lesen des Inhalts einer Datei
if pfad.is_file():
    with open(pfad) as datei:
        inhalt = datei.read()
    print("Der Inhalt der Datei lautet:")
    print(inhalt)

# Navigieren durch Verzeichnisse und Auflisten von Dateien
verzeichnis = Path("some_directory")

print("Dateien im Verzeichnis:")
for element in verzeichnis.iterdir():
    if element.is_file():
        print(element.name)
